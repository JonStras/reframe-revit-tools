#! python3
# -*- coding: utf-8 -*-
"""Break Up

Convert eligible modeled elements into Revit Parts and stamp module data onto
every resulting part. This reproduces the Dynamo "The Break Up" Python node from
the Revit -> Onshape export workflow.

For each input element it:
  1. Creates Revit Parts (only if the element supports Parts and doesn't have
     them yet).
  2. Copies parameter values from the parent element onto every part it creates:
        MODULE       ->  MODULE
        Panel Type   ->  Original Panel Type
     The parent's INSTANCE value is read first; if empty, it falls back to the
     element's TYPE parameter (Panel Type lives at the type level).

Default scope: every eligible modeled element whose MODULE parameter is not
blank. Select elements before running to override the scope with that selection.
"""

__title__ = "Break\nUp"
__author__ = "Reframe Systems"

from System.Collections.Generic import List

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

# Hardcoded parameter transfer map: source (parent) param -> destination (part) param
PARAM_MAP = {
    "MODULE":     "MODULE",
    "Panel Type": "Original Panel Type",
}

# Element classes that are never "physical modeled" elements
EXCLUDED_TYPES = (DB.View, DB.ViewSheet, DB.PropertySetElement, DB.Material)


def gather_modeled_elements(document):
    """Replicates the 'Grabbing Everything Modeled' filter: keep model-category,
    view-independent elements that have a real bounding box."""
    collector = (DB.FilteredElementCollector(document)
                 .WhereElementIsNotElementType()
                 .WhereElementIsViewIndependent())
    elements = []
    for el in collector:
        try:
            if isinstance(el, EXCLUDED_TYPES):
                continue
            cat = el.Category
            if cat is None or cat.CategoryType != DB.CategoryType.Model:
                continue
            if el.get_BoundingBox(None) is None:
                continue
            elements.append(el)
        except Exception:
            pass
    return elements


def read_source_value(element, src_param):
    """Instance parameter first, then fall back to the element's type."""
    p = element.LookupParameter(src_param)
    if p and p.HasValue:
        return p.AsString()
    type_id = element.GetTypeId()
    if type_id and type_id != DB.ElementId.InvalidElementId:
        el_type = doc.GetElement(type_id)
        if el_type is not None:
            tp = el_type.LookupParameter(src_param)
            if tp and tp.HasValue:
                return tp.AsString()
    return None


def has_module_value(element):
    """True if the element's MODULE parameter (instance, or type fallback)
    has a non-blank value."""
    val = read_source_value(element, "MODULE")
    return val is not None and val.strip() != ""


def break_up(elements):
    created_parts = []
    n_ok = 0
    n_skip = 0
    n_err = 0
    log_lines = []

    t = DB.Transaction(doc, "Reframe - Break Up (Create Parts)")
    t.Start()
    try:
        for el in elements:
            if el is None:
                continue
            cat_name = el.Category.Name if el.Category else "Unknown Category"
            try:
                id_list = List[DB.ElementId]()
                id_list.Add(el.Id)

                if not DB.PartUtils.AreElementsValidForCreateParts(doc, id_list):
                    log_lines.append("SKIP   {0} ({1}) - does not support Parts".format(el.Id, cat_name))
                    n_skip += 1
                    continue

                # Create parts if they don't exist yet
                if not DB.PartUtils.HasAssociatedParts(doc, el.Id):
                    DB.PartUtils.CreateParts(doc, id_list)
                    doc.Regenerate()  # commit geometry so parts receive IDs

                # Read all source values from the parent before touching parts
                source_values = {}
                for src, dst in PARAM_MAP.items():
                    source_values[dst] = read_source_value(el, src)

                # Transfer to each resulting part
                part_ids = DB.PartUtils.GetAssociatedParts(doc, el.Id, True, True)
                for pid in part_ids:
                    part = doc.GetElement(pid)
                    created_parts.append(part)
                    for dst_param, val in source_values.items():
                        if val is None:
                            continue
                        part_param = part.LookupParameter(dst_param)
                        if part_param and not part_param.IsReadOnly:
                            part_param.Set(val)

                n_ok += 1
                log_lines.append("OK     {0} ({1})".format(el.Id, cat_name))

            except Exception as ex:
                n_err += 1
                log_lines.append("ERROR  {0} ({1}): {2}".format(el.Id, cat_name, ex))

        t.Commit()
    except Exception:
        if t.HasStarted() and not t.HasEnded():
            t.RollBack()
        raise

    return created_parts, n_ok, n_skip, n_err, log_lines


def main():
    # Default: every eligible modeled element whose MODULE parameter is not blank.
    # Override: if the user has a selection, that selection is used instead.
    selection = revit.get_selection()

    if selection and len(selection) > 0:
        elements = list(selection.elements)
        scope = "{0} selected element(s)".format(len(elements))
    else:
        elements = [el for el in gather_modeled_elements(doc) if has_module_value(el)]
        scope = "{0} modeled element(s) with a MODULE value".format(len(elements))

    if not elements:
        forms.alert("No eligible elements found to break up.\n\n"
                    "Default scope is modeled elements with a non-blank MODULE "
                    "parameter; select elements to override.",
                    title="Break Up")
        return

    if not forms.alert("Run 'Break Up' on {0}?".format(scope),
                       title="Break Up", yes=True, no=True):
        return

    parts, n_ok, n_skip, n_err, log_lines = break_up(elements)

    output.print_md("### Break Up - results")
    summary = ("- **{0}** elements broken up\n"
               "- **{1}** parts created/updated\n"
               "- **{2}** skipped (no Parts support)\n"
               "- **{3}** errors").format(n_ok, len(parts), n_skip, n_err)
    output.print_md(summary)
    for line in log_lines:
        print(line)

    msg = ("Break Up complete.\n\n"
           "Broken up: {0}\n"
           "Parts created/updated: {1}\n"
           "Skipped (no Parts support): {2}\n"
           "Errors: {3}\n\n"
           "See the pyRevit output window for the full log."
           ).format(n_ok, len(parts), n_skip, n_err)
    forms.alert(msg, title="Break Up")


if __name__ == "__main__":
    main()

# ReframeTools — pyRevit extension

Reframe Revit automation tools for the 201 Hampden Revit → Onshape export workflow.

## Layout

```
ReframeTools.extension/
  extension.json
  Reframe.tab/
    Modules.panel/
      Populate Module.pushbutton/      (existing)
      Break Up.pushbutton/             (new)
        script.py
        bundle.yaml
        icon.png
```

## Break Up button

Translates the Dynamo **"The Break Up"** Python node into a one-click pyRevit command. For each input element it:

1. Creates Revit **Parts** — only if the element supports Parts and doesn't already have them (`PartUtils.AreElementsValidForCreateParts` / `HasAssociatedParts` / `CreateParts`, with a `doc.Regenerate()` so the new parts get IDs).
2. Copies parameters from the parent onto every resulting part:
   - `MODULE` → `MODULE`
   - `Panel Type` → `Original Panel Type`
   - Instance value first, then the element **type** as a fallback (Panel Type is a type-level parameter).

All work runs inside a single transaction (`Reframe - Break Up (Create Parts)`), so one Ctrl+Z undoes the whole run.

### Input behavior (added for the button)

The Dynamo node was fed by the upstream "Grabbing Everything Modeled" filter. The button reproduces that:

- **Elements selected** → asks whether to run on the selection or on all eligible elements.
- **Nothing selected** → offers to run on every eligible modeled element (model category, view-independent, has a bounding box; Views/Sheets/PropertySets/Materials excluded).

Results are summarized in a dialog and printed in full to the pyRevit output window.

## Install

1. Copy the `ReframeTools.extension` folder into your pyRevit extensions directory, e.g.
   `%APPDATA%\pyRevit\Extensions\` — or add its parent folder under
   pyRevit Settings → Custom Extension Directories.
2. Reload pyRevit (pyRevit tab → Reload) or restart Revit.
3. The button appears under **Reframe → Modules → Break Up**.

Engine: the script uses `#! python3` (pyRevit CPython), matching the Dynamo CPython3 node. It also runs on the IronPython engine if you remove the shebang.

## Notes / next steps

- `doc.Regenerate()` is called once per element (faithful to the original). For large runs this is the main cost; batching part creation and regenerating once per chunk is a future optimization.
- Natural companions in the same workflow that could become buttons next: the
  module-volume / naming step (now group-based), the Panels view generator
  (Script 2), and the MEPP view generator (Script 3).
